var points = [  //物品的参数
    { p: [{ x: 0 + 1152, y: 0 }, { x: 200 + 1152, y: 0 }, { x: 100 + 1152, y: 100 }], color: "#caff67", click: false, drag: false, types: 4, rot: Math.PI },
    { p: [{ x: 0 + 1152, y: 100 }, { x: 200 + 1152, y: 100 }, { x: 100 + 1152, y: 200 }], color: "#67becf", click: false, drag: false, types: 4, rot: Math.PI },
    { p: [{ x: 0 + 1152, y: 200 }, { x: 200 + 1152, y: 200 }, { x: 100 + 1152, y: 300 }], color: "#67becf", click: false, drag: false, types: 4, rot: Math.PI },
    { p: [{ x: 0 + 1152, y: 300 }, { x: 200 + 1152, y: 300 }, { x: 100 + 1152, y: 400 }], color: "#67becf", click: false, drag: false, types: 4, rot: Math.PI },
    { p: [{ x: 0 + 1152, y: 300 }, { x: 200 + 1152, y: 300 }, { x: 100 + 1152, y: 400 }], color: "#67becf", click: false, drag: false, types: 4, rot: Math.PI }
];

var points2 = [ //临时物品
    { p: [{ x: 0 + 1152, y: 0 }, { x: 200 + 1152, y: 0 }, { x: 100 + 1152, y: 100 }], color: "#caff67", click: false, drag: false, types: 4 },
    { p: [{ x: 0 + 1152, y: 100 }, { x: 200 + 1152, y: 100 }, { x: 100 + 1152, y: 200 }], color: "#67becf", click: false, drag: false, types: 4 },
    { p: [{ x: 0 + 1152, y: 200 }, { x: 200 + 1152, y: 200 }, { x: 100 + 1152, y: 300 }], color: "#67becf", click: false, drag: false, types: 4 },
    { p: [{ x: 0 + 1152, y: 300 }, { x: 200 + 1152, y: 300 }, { x: 100 + 1152, y: 400 }], color: "#67becf", click: false, drag: false, types: 4 },
    { p: [{ x: 0 + 1152, y: 300 }, { x: 200 + 1152, y: 300 }, { x: 100 + 1152, y: 400 }], color: "#67becf", click: false, drag: false, types: 4 }
];

var select1 = 0;

var status = 1;

var points_no = -1;

function draw_new() {   //重新刷新画布
    console.log("Let's draw1");
    //alert("draw");
    // 清除画布，准备绘制
    context.clearRect(0, 0, canvas.width, canvas.height);
    context.drawImage(image, 0, 0, 1152, canvas.height);
    //遍历数组，以每个点为起点画图
   
    {
        for (var i = 0; i < points.length; i++) {
            var imageblock = new Image();
            var imagec = new Image();
            imageblock.src = "BFV.png";
            imagec.src = "删除.png";
            context.beginPath();
            context.moveTo(points[i].p[0].x, points[i].p[0].y);
            context.drawImage(imageblock, points[i].p[0].x, points[i].p[0].y, 100, 100);
            console.log("Let's draw2");
            if (i == points_no) {
                context.drawImage(imagec, points[i].p[0].x + 100, points[i].p[0].y - 20, 20, 20);
                drawArrow(points[i].p[0].x, points[i].p[0].y, points[i].rot);
                console.log("draw2");
            }
            
            /*
            for (var j = 0; j < points[i].p.length; j++) {
                context.lineTo(points[i].p[j].x, points[i].p[j].y);
            }
            context.lineTo(points[i].p[0].x, points[i].p[0].y);
            context.strokeStyle = "#caff67";
            context.lineWidth = "3";
            context.fillStyle = points[i].color;
            context.stroke();
            context.fill();
            */
            context.closePath();
        }
    }
}

function buttonClick() {
    console.log("buttonClick");
    if (status == 0) {
        document.getElementById("status").innerHTML = "现在可以修改物品参数";
        status = 1;
        draw_new();
    } else {
        document.getElementById("status").innerHTML = "现在可以添加物品";
        status = 0;
        draw_new();
    }
    /*
    status = (status + 1) % 3;
    //alert("sfs");
    draw_new;
    if (status == 1) {
        document.getElementById("status").innerHTML = "现在可以修改物品方向";
        //draw;
    } else if (status == 2) {
        document.getElementById("status").innerHTML = "现在可以移动物品";
        //draw;
    }
    else if (status == 0) {
        document.getElementById("status").innerHTML = "现在可以增加和删除物品";
        //draw;
    }
    //draw;
    */
}



function drawArrow(fromX, fromY, rot) {
    //先判断障碍物，需要保证箭头的XY坐标都在所有障碍物外面
    var toX = fromX + 30 * Math.cos(rot), toY = fromY + 30 * Math.sin(rot);
    var theta = 30, headlen = 10, width = width || 1, color = "red",
        angle = Math.atan2(fromY - toY, fromX - toX) * 180 / Math.PI,
        angle1 = (angle + theta) * Math.PI / 180, angle2 = (angle - theta) * Math.PI / 180,
        topX = headlen * Math.cos(angle1), topY = headlen * Math.sin(angle1),
        botX = headlen * Math.cos(angle2), botY = headlen * Math.sin(angle2);
    context.save();
    context.beginPath();
    var arrowX, arrowY;
    context.moveTo(fromX, fromY);
    context.lineTo(toX, toY);
    arrowX = toX + topX;
    arrowY = toY + topY;
    context.moveTo(arrowX, arrowY);
    context.lineTo(toX, toY);
    arrowX = toX + botX;
    arrowY = toY + botY;
    context.lineTo(arrowX, arrowY);
    context.strokeStyle = color;
    context.stroke();
    context.restore();
}


function buttonClick1() {
    //alert("delete");
    points.pop();
    points2.pop();
    draw_new();
}
function dragFunction(canvas, context) {
    draw_new();

    canvas.onmousedown = canvasClick;
    canvas.onmouseup = stopdrag;
    canvas.onmouseout = stopdrag;
    canvas.onmousemove = drag;
    canvas.ondblclick = dblik;

    var angles = [];
    var select = -1;
    //把7个点的位置坐标和颜色存入一个数组


    var t_points = [
        {p: [{x: 0 + 1152, y: 0}, {x: 200 + 1152, y: 0}, {x: 100 + 1152, y: 100}], color: "#caff67", click: false, drag: false, types: 4},
        {p: [{x: 0 + 1152, y: 0}, {x: 100 + 1152, y: 100}, {x: 0 + 1152, y: 200}], color: "#67becf", click: false, drag: false, types: 4},
        {
            p: [{x: 200 + 1152, y: 0}, {x: 200 + 1152, y: 100}, {x: 150 + 1152, y: 150}, {x: 150 + 1152, y: 50}],
            color: "#ef3d61",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 150 + 1152, y: 50}, {x: 150 + 1152, y: 150}, {x: 100 + 1152, y: 100}],
            color: "#f9f51a",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 100 + 1152, y: 100}, {x: 150 + 1152, y: 150}, {x: 100 + 1152, y: 200}, {x: 50 + 1152, y: 150}],
            color: "#a594c0",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 50 + 1152, y: 150}, {x: 100 + 1152, y: 200}, {x: 0 + 1152, y: 200}],
            color: "#fa8ecc",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 200 + 1152, y: 100}, {x: 200 + 1152, y: 200}, {x: 100 + 1152, y: 200}],
            color: "#f6ca29",
            click: false,
            drag: false,
            types: 4
        }
    ];
    var t_points2 = [
        {p: [{x: 0 + 1152, y: 0}, {x: 200 + 1152, y: 0}, {x: 100 + 1152, y: 100}], color: "#caff67", click: false, drag: false, types: 4},
        {p: [{x: 0 + 1152, y: 0}, {x: 100 + 1152, y: 100}, {x: 0 + 1152, y: 200}], color: "#67becf", click: false, drag: false, types: 4},
        {
            p: [{x: 200 + 1152, y: 0}, {x: 200 + 1152, y: 100}, {x: 150 + 1152, y: 150}, {x: 150 + 1152, y: 50}],
            color: "#ef3d61",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 150 + 1152, y: 50}, {x: 150 + 1152, y: 150}, {x: 100 + 1152, y: 100}],
            color: "#f9f51a",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 100 + 1152, y: 100}, {x: 150 + 1152, y: 150}, {x: 100 + 1152, y: 200}, {x: 50 + 1152, y: 150}],
            color: "#a594c0",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 50 + 1152, y: 150}, {x: 100 + 1152, y: 200}, {x: 0 + 1152, y: 200}],
            color: "#fa8ecc",
            click: false,
            drag: false,
            types: 4
        },
        {
            p: [{x: 200 + 1152, y: 100}, {x: 200 + 1152, y: 200}, {x: 100 + 1152, y: 200}],
            color: "#f6ca29",
            click: false,
            drag: false,
            types: 4
        }
    ];

    


    draw_new();
    var isDragging = false;
    var isDraggingArray = false;


    function canvasClick(e) {
        console.log("It is clicked!!");

        //如果点击到物品上
        var clickX = e.pageX - canvas.offsetLeft;
        //触摸地点在画布上
        if (clickX <= 1152) {
            console.log('<= 1152!!!')
        }

        var clickY = e.pageY - canvas.offsetTop;

        if (status == 0) {  //添加物品
            //我的想法是使用一个标记记录选中的物品是什么，按照标记添加物品，目前暂时使用坦克1
            var newpoint = { p: [{ x: clickX, y: clickY }, { x: 200 + clickX, y: clickY }, { x: 100 + clickX, y: 100 + clickY }], color: "#caff67", click: false, drag: false, types: 4, rot: Math.PI }
            points[points.length] = newpoint;
            points2[points2.length] = newpoint;
            //alert("暂时先不搞");
            draw_new();
        } else if (status == 1) {   //点击物品可选中，点击地图可拖动（暂不搞）
            var complete = -1;
            for (var i = 0; i < points.length; i++) {
                console.log('first')
                context.beginPath();
                //context.arc(points[i].p[0].x + 30 * Math.cos(points[i].rot), points[i].p[0].y + 30 * Math.sin(points[i].rot), 10, 0, Math.PI * 2);//以箭头的头部画一个小圆，如果鼠标点在这个圆内，视为开始拖动该箭头
                var flag = false;
                if (points[i].types == 3) {
                    flag = anglecompult(points[i].p, clickX, clickY);
           
                    status = 2;
                    console.log("end1");
                }
                else if (points[i].types == 4) {
                    flag = reactcompult(points[i].p, clickX, clickY);
                    status = 2;
                    console.log("end2");
                }
                if (flag == true) {
                    points_no = i;
                    console.log('selected');
                    complete = i;
                } 
                /*
                if (context.isPointInPath(clickX, clickY)) {
                    console.log('second')
                    points_no = i;
                    status = 2;
                    draw_new;
                    break;
                }
                */
                draw_new();
            }
            if (complete == -1) {   //没有选中物品
                points_no = -1;
                status = 1;
                draw_new();
                console.log("end1233");
            }
        

        } else if (status == 2) {   //已选中物品，可点击物品，叉号，箭头，地图
            console.log('status2');
            var dont = 0;
            //for (var i = 0; i < points.length; i++)        //这里不需要循环 

                context.beginPath();    //箭头
            context.arc(points[points_no].p[0].x + 30 * Math.cos(points[points_no].rot), points[points_no].p[0].y + 30 * Math.sin(points[points_no].rot), 10, 0, Math.PI * 2); //以箭头的头部画一个小圆，如果鼠标点在这个圆内，视为开始拖动该箭头
                if (context.isPointInPath(clickX, clickY)) {
                    //alert("drag");
                    isDraggingArray = true;
                    console.log('second实打实大放送')
                    select1 = points_no;
                    dont = 1;
                    return;
                    //canvas.

                    //鼠标移开事件
                    //alert("end");
            }
            context.beginPath();    //叉号
            //context.moveTo(points[points_no].p[0].x, points[points_no].p[0].y);
            context.rect(points[points_no].p[0].x + 100, points[points_no].p[0].y - 20, 20, 20);
            if (context.isPointInPath(clickX, clickY)) {
                points.splice(points_no, 1);
                points2.splice(points_no, 1);
                points_no = -1;
                status = 1;
                draw_new();
                return;
            }

            context.beginPath();    //拖动物体
            //context.moveTo(points[points_no].p[0].x, points[points_no].p[0].y);
            context.rect(points[points_no].p[0].x, points[points_no].p[0].y, 100, 100);
            if (context.isPointInPath(clickX, clickY)) {
                console.log("fin");
                isDragging = true;
                points[points_no].click = true;
                points[points_no].drag = true;
                select = points_no;
                return;
            }


                //如果物品，叉号，箭头都没有点中，则取消选中
                if (dont == 0 ) {
                points_no = -1;
                status = 1;
                draw_new();
                }

            

            //status = 1;
        }
        /*
        if (status == 0) {//添加物品
            var clickX = e.pageX - canvas.offsetLeft;
            var clickY = e.pageY - canvas.offsetTop;
            var newpoint = { p: [{ x: clickX, y: clickY }, { x: 200 + clickX, y: clickY }, { x: 100 + clickX, y: 100 + clickY }], color: "#caff67", click: false, drag: false, types: 4, rot: Math.PI }
            points[points.length] = newpoint;
            points2[points2.length] = newpoint;
            //alert("暂时先不搞");
            draw_new;
        }
        else if (status == 1) {//修改方向
            isDraggingArray = true;
            //alert("测试");
            draw_new();
            var x = e.pageX - canvas.offsetLeft;
            var y = e.pageY - canvas.offsetTop;
            for (var i = 0; i < points.length; i++) {
                console.log('first')
                context.beginPath();
                context.arc(points[i].p[0].x + 30 * Math.cos(points[i].rot), points[i].p[0].y + 30 * Math.sin(points[i].rot), 10, 0, Math.PI * 2);//以箭头的头部画一个小圆，如果鼠标点在这个圆内，视为开始拖动该箭头
                if (context.isPointInPath(x, y)) {
                    //alert("drag");
                    console.log('second')
                    select1 = i;
                    //canvas.
                    
                    //鼠标移开事件
                    //alert("end");
                }

            }
            //draw_new();
        }
        else if (status == 2) {//移动物品

        
        // 取得画布上被单击的点


        for (var i = 0; i < points.length; i++) {
            var flag = false;
            if (points[i].types == 3) {
                flag = anglecompult(points[i].p, clickX, clickY);
            } else if (points[i].types == 4) {
                flag = reactcompult(points[i].p, clickX, clickY);
            }
            if (flag == true) {
                isDragging = true;
                points[i].click = true;
                points[i].drag = true;
                select = i;
            } else {
                backgroudMouseDown(e);
                points[i].click = false;
                points[i].drag = false;
            }
        }
        }
        */
    }

    function dblik(e) {
        console.log("It is doubled clicked!!");
        //双击一块转动45度角
        // 判断圆圈是否开始拖拽
        // 判断拖拽对象是否存在

        if (status != 3) {
            return;
        }
        // 取得鼠标位置
        var x = e.pageX - canvas.offsetLeft;
        var y = e.pageY - canvas.offsetTop;

        // 将圆圈移动到鼠标位置
        var changdu = points[select].p.length;

        var yuanX = points[select].p[0].x;
        var yuanY = points[select].p[0].y;

        var yuanX2 = points2[select].p[0].x;
        var yuanY2 = points2[select].p[0].y;
        var xianx;
        var xianx2;
        var xiany;
        var xiany2;
        var xiebian;
        for (var j = 1; j < changdu; j++) {
            xianx = (points[select].p[j].x - yuanX) * (Math.cos((2 * Math.PI / 360) * 45)) - (points[select].p[j].y - yuanY) * (Math.sin((2 * Math.PI / 360) * 45)) + yuanX;
            xiany = (points[select].p[j].x - yuanX) * (Math.sin((2 * Math.PI / 360) * 45)) + (points[select].p[j].y - yuanY) * (Math.cos((2 * Math.PI / 360) * 45)) + yuanY;
            points[select].p[j].x = xianx;
            points[select].p[j].y = xiany;

            xianx2 = (points2[select].p[j].x - yuanX2) * (Math.cos((2 * Math.PI / 360) * 45)) - (points2[select].p[j].y - yuanY2) * (Math.sin((2 * Math.PI / 360) * 45)) + yuanX2;
            xiany2 = (points2[select].p[j].x - yuanX2) * (Math.sin((2 * Math.PI / 360) * 45)) + (points2[select].p[j].y - yuanY2) * (Math.cos((2 * Math.PI / 360) * 45)) + yuanY2;
            points2[select].p[j].x = xianx2;
            points2[select].p[j].y = xiany2;
        }
        console.log(points[select].p);
        // 更新画布
        draw_new();

    }

    function drag(e) {
        console.log("It is dragged!!");
        // 判断圆圈是否开始拖拽
        if (status == 2 && select1 >= 0) {
            if (isDraggingArray == true) {
                console.log("It is drasfsdfsgged!!");
                
                //alert("onmove");
                console.log('third')
                var x = e.pageX - canvas.offsetLeft;
                var y = e.pageY - canvas.offsetTop;
                //鼠标移动每一帧都清楚画布内容，然后重新画圆
                //alert("dfs1");
                points[select1].rot = Math.atan2(y - points[select1].p[0].y, x - points[select1].p[0].x);
                //alert("ddd");
                context.clearRect(0, 0, canvas.width, canvas.height);
                draw_new();
                //alert("fss");
            };
            //return;
        }
        if (isDragging == true) {
            // 判断拖拽对象是否存在
            console.log("dragdrag");
            // 取得鼠标位置
            var x = e.pageX - canvas.offsetLeft;
            var y = e.pageY - canvas.offsetTop;


            var changdu = points[select].p.length;

            var xx = x - points2[select].p[0].x;
            var yy = y - points2[select].p[0].y;
            if (status == 1) {  //拖动箭头改变方向
                
            }
            else {
                for (var j = 0; j < changdu; j++) {//将图形拖动到鼠标相应位置
                    points[select].p[j].x = points2[select].p[j].x + xx;
                    points[select].p[j].y = points2[select].p[j].y + yy;
                }
                // 更新画布
                draw_new();

            }

        } else {
            backgroundMouseMove(e);
        }
    }

    function stopdrag(e) {
        console.log("It is stop dragged!!");
        isDragging = false;
        isDraggingArray = false;
        if (status == 1) {
            return;
        }
        backgroundOnMouseUp(e);
        //draw_new;
        if (status == 1) {
            for (var i = 0; i < points.length; i++) {
                //drawArrow(points.p[0].x, points.p[0].y, points.p[0].rot);
            }
            return;
        }
        draw_new();
        
    }

    function anglecompult(anglepostions, x, y) {//判断三角形内
        var first = anglepostions[0];
        var second = anglepostions[1];
        var third = anglepostions[2];

        var firstR = ((second.y - third.y) * (x - third.x) + (third.x - second.x) * (y - third.y)) / ((second.y - third.y) * (first.x - third.x) + (third.x - second.x) * (first.y - third.y));

        var secondR = ((third.y - first.y) * (x - third.x) + (first.x - third.x) * (y - third.y)) / ((second.y - third.y) * (first.x - third.x) + (third.x - second.x) * (first.y - third.y))

        var thirsR = 1 - firstR - secondR;

        if (firstR > 0 && firstR < 1 && secondR > 0 && secondR < 1 && thirsR > 0 && thirsR < 1) {
            return true;
        } else {
            return false;
        }
    }

    function reactcompult(reactpostions, x, y) {//判断鼠标是否在矩形区域内
        var xmin, xmax, ymin, ymax;
        xmin = xmax = reactpostions[0].x;
        ymin = ymax = reactpostions[0].y;
        for (var i = 0; i < reactpostions.length; i++) {
            if (reactpostions[i].x < xmin) {
                xmin = reactpostions[i].x;
            }
            if (reactpostions[i].x > xmax) {
                xmax = reactpostions[i].x;
            }
            if (reactpostions[i].y < ymin) {
                ymin = reactpostions[i].y;
            }
            if (reactpostions[i].y > ymax) {
                ymax = reactpostions[i].y;
            }
        }

        if (xmin < x && xmax > x && ymin < y && ymax > y) {
            return true;
        } else {
            return false;
        }
    }
}